package za.ac.iie.fumosmusicapp.thehistoryflashcards

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity2 : AppCompatActivity() {

    private val flashcards = arrayOf(
        "The Declaration of Independence was signed in 1977",
        "Nelson Mandela was Released in 1994",
        "The Pyramids are in Egypt",
        "The Berlin Wall is in Germany",
        "World War ended in 1946",
        "The Wall of China is 2500m"
    )

    private val answers = arrayOf(false, true, true, true, false, false)
    private var currentQuestion = 0
    private var score = 0

    private lateinit var questionText: TextView
    private lateinit var reviewText: TextView
    private lateinit var falseButton: Button
    private lateinit var nextButton: Button
    private lateinit var trueButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)

        score = intent.getIntExtra("score", 0)

        questionText = findViewById(R.id.questionText)
        trueButton = findViewById(R.id.trueButton)
        falseButton = findViewById(R.id.falseButton)
        reviewText = findViewById(R.id.reviewText)
        nextButton = findViewById(R.id.nextButton)

        showQuestion()

        trueButton.setOnClickListener {
            checkAnswer(true)
        }

        falseButton.setOnClickListener {
            checkAnswer(false)
        }

        nextButton.setOnClickListener {
            currentQuestion++
            if (currentQuestion < flashcards.size) {
                showQuestion()
            } else {
                val intent = Intent(this, MainActivity3::class.java)
                intent.putExtra("score", score)
                startActivity(intent)
                finish()
            }
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.questionText)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun showQuestion() {
        questionText.text = flashcards[currentQuestion]
        reviewText.text = ""
        trueButton.isEnabled = true
        falseButton.isEnabled = true
        nextButton.isEnabled = false
    }

    private fun checkAnswer(userAnswer: Boolean) {
        val correctAnswer = answers[currentQuestion]
        if (userAnswer == correctAnswer) {
            score++
            reviewText.text = "Correct!"
        } else {
            reviewText.text = "Incorrect!"
        }

        trueButton.isEnabled = false
        falseButton.isEnabled = false
        nextButton.isEnabled = true
    }
}
