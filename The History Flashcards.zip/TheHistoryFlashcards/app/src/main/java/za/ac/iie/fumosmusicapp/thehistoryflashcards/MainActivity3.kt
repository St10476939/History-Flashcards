package za.ac.iie.fumosmusicapp.thehistoryflashcards

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity3 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main3)

        val score = intent.getIntExtra("score", 0)
        val questions = intent.getStringArrayExtra("questions") ?: arrayOf()
        val answers = intent.getBooleanArrayExtra("answers") ?: BooleanArray(questions.size)

        val scoreText = findViewById<TextView>(R.id.scoreText)
        val commentTxt = findViewById<TextView>(R.id.commentTxt)
        val exitButton = findViewById<Button>(R.id.exitButton)

        scoreText.text = "Your score: $score / ${questions.size}"
        commentTxt.text = if (score >= 3) "Great work!" else "Work Harder!"

        commentTxt.setOnClickListener {
            val reviewText = questions.mapIndexed { index, question ->
                "Q${index + 1}: $question\nAnswer: ${if (answers[index]) "True" else "False"}"
            }.joinToString("\n\n")

            AlertDialog.Builder(this)
                .setTitle("Review Answers")
                .setMessage(reviewText)
                .setPositiveButton("OK", null)
                .show()
        }

        exitButton.setOnClickListener {
            finishAffinity() // Terminates the app
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.scoreText)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}
